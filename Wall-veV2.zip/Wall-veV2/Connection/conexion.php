<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "wallve";

$conexion = new mysqli($server, $user, $pass, $db);
?>